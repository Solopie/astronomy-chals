# What Planet is that?

Description: Will be a quiz to identify planet based on planet. Picture of planet shown and input box to identify name of the planet.

## Normal solve

Answer all the planets correctly with your big brain.

## Hacker solve

Route to the flag is in source code.
